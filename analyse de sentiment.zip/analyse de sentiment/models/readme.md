# Modèles entraînés

## DistilBERT pour l'analyse de sentiments

### Téléchargement
Les modèles sont trop volumineux pour GitHub. Téléchargez-les ici :

- **Modèle principal** : [distilbert-sentiment-final.zip](lien_de_téléchargement)
- **Checkpoints** : [checkpoints.zip](lien_de_téléchargement)

### Instructions
1. Dézippez les modèles dans ce dossier
2. Structure attendue :