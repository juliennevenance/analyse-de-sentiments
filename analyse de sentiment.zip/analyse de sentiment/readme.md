=============================================
PROJET D'ANALYSE DE SENTIMENTS - JULIENNE
=============================================

📋 DESCRIPTION
API d'analyse de sentiments des avis clients utilisant DistilBERT.
Classification en 5 catégories : Très négatif → Très positif.

🚀 INSTALLATION RAPIDE
1. Extraire le ZIP
2. Ouvrir un terminal dans le dossier extrait
3. Installer : pip install -r requirements.txt
4. Lancer l'API : cd api && python app.py
5. Tester : ouvrir http://localhost:8000/docs

📊 RÉSULTATS
- Modèle : DistilBERT fine-tuné
- Données : 650 000 avis clients
- Accuracy : 52% (5 classes)
- API : FastAPI fonctionnelle

🎯 EXEMPLES DE PRÉDICTIONS
• "This product is amazing!" → Très positif (86.7%)
• "Worst experience ever" → Très négatif (84.0%)
• "It's okay, nothing special" → Neutre (52.7%)

📁 STRUCTURE
• API/ : Code de l'API FastAPI
• Notebooks/ : Analyses et entraînement
• Modèles/ : Modèle DistilBERT entraîné
• Données/ : Jeu de données nettoyé


MODÈLES COMPLETS DISPONIBLES SUR :
https://drive.google.com/drive/folders/...

Contient :
- models/distilbert-sentiment-final (modèle complet)
- models/distilbert-sentiment
- data/processed/train_cleaned.parquet (données nettoyées)
- data/processed/test_cleaned.parquet

Pour utiliser :
1. Télécharger depuis Google Drive
2. Placer dans les dossiers correspondants