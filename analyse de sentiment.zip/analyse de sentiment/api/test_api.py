# test_api.py - Version corrigée
import requests
import json

BASE_URL = "http://localhost:8000"

def test_api():
    print("🧪 Test de l'API d'analyse de sentiments...")
    
    # Test 1: Vérification de santé
    print("\n1. Test de santé:")
    response = requests.get(f"{BASE_URL}/health")
    print(f"   Status: {response.status_code}")
    print(f"   Réponse: {json.dumps(response.json(), indent=2, ensure_ascii=False)}")
    
    # Test 2: Prédictions multiples simples
    print("\n2. Tests de prédiction:")
    
    test_texts = [
        "This product is absolutely amazing! I love it!",
        "Worst experience ever, would not recommend.",
        "It's okay, nothing special but works fine.",
        "Excellent service, highly recommended!",
        "Terrible quality, broke immediately."
    ]
    
    for i, text in enumerate(test_texts, 1):
        print(f"\n   Test {i}: '{text[:50]}...'")
        
        payload = {"text": text}
        response = requests.post(f"{BASE_URL}/predict", json=payload)
        
        if response.status_code == 200:
            result = response.json()
            print(f"      → {result['sentiment']} (classe {result['prediction']})")
            print(f"      Confiance: {result['confidence']}%")
        else:
            print(f"      ❌ Erreur: {response.status_code}")
    
    # Test 3: Analyse détaillée d'un cas
    print("\n3. Analyse détaillée:")
    detailed_text = "The camera quality is exceptional, battery life could be better though. Overall good product."
    
    response = requests.post(f"{BASE_URL}/predict", json={"text": detailed_text})
    
    if response.status_code == 200:
        result = response.json()
        print(f"   Texte: '{detailed_text}'")
        print(f"   Sentiment: {result['sentiment']}")
        print(f"   Confiance: {result['confidence']}%")
        print(f"   Probabilités:")
        for sentiment, prob in result['probabilities'].items():
            print(f"     - {sentiment}: {prob}%")
    
    print("\n✅ Tests terminés!")
    print(f"\n📌 Accès API:")
    print(f"   - Documentation: {BASE_URL}/docs")
    print(f"   - Page d'accueil: {BASE_URL}/")

if __name__ == "__main__":
    test_api()