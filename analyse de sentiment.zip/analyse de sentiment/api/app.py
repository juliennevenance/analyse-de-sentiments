# api/app.py - VERSION CORRIGÉE
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification
import torch
import uvicorn
import os
from pathlib import Path
import logging
import sys

# Configuration du logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialisation de l'app FastAPI
app = FastAPI(
    title="API d'Analyse de Sentiments",
    description="API pour classifier les avis clients en 5 catégories de sentiment",
    version="1.0.0"
)

# Modèles Pydantic
class ReviewRequest(BaseModel):
    text: str
    max_length: int = 128

class SentimentResponse(BaseModel):
    text: str
    prediction: int
    sentiment: str
    confidence: float
    probabilities: dict

# ========== CHARGEMENT INTELLIGENT DU MODÈLE ==========

def find_model_path():
    """Trouve automatiquement le chemin du modèle"""
    possible_paths = [
        # Depuis le dossier api/
        Path("models/distilbert-sentiment-final"),
        Path("../models/distilbert-sentiment-final"),  # Un niveau au-dessus
        Path("../../models/distilbert-sentiment-final"),  # Deux niveaux au-dessus
        
        # Chemins absolus
        Path(__file__).parent / "models/distilbert-sentiment-final",
        Path(__file__).parent.parent / "models/distilbert-sentiment-final",
    ]
    
    for path in possible_paths:
        if path.exists():
            logger.info(f"✅ Modèle trouvé à: {path.absolute()}")
            return path
    
    # Si aucun chemin ne marche, lister ce qui existe
    logger.error("❌ Modèle non trouvé. Recherche dans les dossiers...")
    for root, dirs, files in os.walk(Path(__file__).parent.parent, topdown=False):
        for name in dirs:
            if "distilbert" in name.lower() or "sentiment" in name.lower():
                logger.info(f"   Dossier trouvé: {os.path.join(root, name)}")
    
    raise FileNotFoundError("Modèle DistilBERT non trouvé. As-tu bien entraîné le modèle ?")

# Chargement du modèle
try:
    MODEL_PATH = find_model_path()
    logger.info(f"🔍 Chargement du modèle depuis: {MODEL_PATH}")
    
    # Charger le tokenizer et le modèle
    tokenizer = DistilBertTokenizerFast.from_pretrained(MODEL_PATH)
    model = DistilBertForSequenceClassification.from_pretrained(MODEL_PATH)
    
    # Passer en mode évaluation
    model.eval()
    
    logger.info("✅ Modèle et tokenizer chargés avec succès!")
    
except Exception as e:
    logger.error(f"❌ Erreur lors du chargement du modèle: {e}")
    logger.info("\n💡 SOLUTION: Entraîne d'abord le modèle avec:")
    logger.info("   python notebooks/03_distilbert_training.ipynb")
    logger.info("   ou exécute la cellule d'entraînement dans le notebook")
    sys.exit(1)

# Mapping des sentiments
SENTIMENT_MAP = {
    0: "Très négatif",
    1: "Négatif", 
    2: "Neutre",
    3: "Positif",
    4: "Très positif"
}

# ========== ENDPOINTS ==========

@app.get("/")
async def root():
    return {
        "message": "API d'Analyse de Sentiments",
        "status": "actif",
        "model": "DistilBERT (5 classes)",
        "endpoints": {
            "/": "Cette page",
            "/health": "Vérification de santé",
            "/predict": "Prédiction de sentiment (POST)"
        }
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "model_loaded": True,
        "model_path": str(MODEL_PATH),
        "sentiment_classes": SENTIMENT_MAP
    }

@app.post("/predict", response_model=SentimentResponse)
async def predict_sentiment(request: ReviewRequest):
    """Analyse le sentiment d'un texte donné."""
    try:
        # Tokenization
        inputs = tokenizer(
            request.text,
            truncation=True,
            padding=True,
            max_length=request.max_length,
            return_tensors="pt"
        )
        
        # Prédiction
        with torch.no_grad():
            outputs = model(**inputs)
            probabilities = torch.nn.functional.softmax(outputs.logits, dim=-1)
            prediction = torch.argmax(probabilities, dim=-1).item()
            confidence = probabilities[0][prediction].item()
        
        # Formatage des probabilités
        prob_dict = {
            SENTIMENT_MAP[i]: round(probabilities[0][i].item() * 100, 2)
            for i in range(len(SENTIMENT_MAP))
        }
        
        return SentimentResponse(
            text=request.text[:100] + "..." if len(request.text) > 100 else request.text,
            prediction=prediction,
            sentiment=SENTIMENT_MAP[prediction],
            confidence=round(confidence * 100, 2),
            probabilities=prob_dict
        )
        
    except Exception as e:
        logger.error(f"Erreur lors de la prédiction: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ========== LANCEMENT ==========

if __name__ == "__main__":
    print("🚀 Lancement de l'API d'Analyse de Sentiments...")
    print(f"📌 Modèle chargé depuis: {MODEL_PATH}")
    print("🌐 Accès à l'API:")
    print("   - Documentation: http://localhost:8000/docs")
    print("   - Health check: http://localhost:8000/health")
    print("   - Page d'accueil: http://localhost:8000/")
    print("\n📝 Test rapide:")
    print('   curl -X POST "http://localhost:8000/predict" \\')
    print('     -H "Content-Type: application/json" \\')
    print('     -d \'{"text": "This product is amazing!"}\'')
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )